sed -e '/^\/\/\# source/d' -i '' dist/es6-shim.js 
