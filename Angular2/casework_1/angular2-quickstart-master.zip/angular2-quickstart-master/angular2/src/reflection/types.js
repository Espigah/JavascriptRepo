System.register([], function($__export) {
  "use strict";
  var SetterFn,
      GetterFn,
      MethodFn;
  return {
    setters: [],
    execute: function() {
      SetterFn = $__export("SetterFn", Function);
      GetterFn = $__export("GetterFn", Function);
      MethodFn = $__export("MethodFn", Function);
    }
  };
});

//# sourceMappingURL=src/reflection/types.map

//# sourceMappingURL=../../src/reflection/types.js.map